ALTER TABLE `client_knowledge_bases` MODIFY COLUMN `products` mediumtext;--> statement-breakpoint
ALTER TABLE `client_knowledge_bases` MODIFY COLUMN `targetDemographics` mediumtext;--> statement-breakpoint
ALTER TABLE `client_knowledge_bases` MODIFY COLUMN `targetPsychographics` mediumtext;--> statement-breakpoint
ALTER TABLE `client_knowledge_bases` MODIFY COLUMN `painPoints` mediumtext;--> statement-breakpoint
ALTER TABLE `client_knowledge_bases` MODIFY COLUMN `desires` mediumtext;--> statement-breakpoint
ALTER TABLE `client_knowledge_bases` MODIFY COLUMN `toneExamples` mediumtext;--> statement-breakpoint
ALTER TABLE `client_knowledge_bases` MODIFY COLUMN `antiToneExamples` mediumtext;--> statement-breakpoint
ALTER TABLE `client_knowledge_bases` MODIFY COLUMN `usp` mediumtext;--> statement-breakpoint
ALTER TABLE `client_knowledge_bases` MODIFY COLUMN `differentiators` mediumtext;--> statement-breakpoint
ALTER TABLE `client_knowledge_bases` MODIFY COLUMN `valueProposition` mediumtext;